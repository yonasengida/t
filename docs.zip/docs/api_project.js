define({
  "name": "PF-API",
  "version": "1.0.0",
  "description": "PF RESTful API",
  "title": "PF documentation",
  "url": "http://159.65.228.222:8080",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2018-02-28T09:01:45.208Z",
    "url": "http://apidocjs.com",
    "version": "0.17.6"
  }
});
