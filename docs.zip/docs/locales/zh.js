define({
    zh: {
        'Allowed values​​:'             : '允許值:',
        'Compare all with predecessor': '預先比較所有',
        'compare changes to:'         : '比較變更:',
        'compared to'                 : '對比',
        'Default value:'              : '默認值:',
        'Description'                 : '描述',
        'Field'                       : '字段',
        'General'                     : '概括',
        'Generated with'              : '生成工具',
        'Name'                        : '名稱',
        'No response values​​.'         : '無對應資料.',
        'optional'                    : '選項',
        'Parameter'                   : '參數',
        'Permission:'                 : '允許:',
        'Response'                    : '回應',
        'Send'                        : '發送',
        'Send a Sample Request'       : '發送試用需求',
        'show up to version:'         : '顯示到版本:',
        'Size range:'                 : '尺寸範圍:',
        'Type'                        : '類型',
        'url'                         : '網址'
    }
});
